// content.js
// Variable pour éviter les doubles déclenchements
let popupIsVisible = false;

// Les mots clés qui indiquent SPÉCIFIQUEMENT un bouton d'achat
// Liste plus restrictive pour éviter les faux positifs
const buyKeywords = [
  'acheter', 'ajouter au panier', 'add to cart', 'add to bag',
  'commander maintenant', 'buy now', 'checkout', 'payer',
  'procéder à l\'achat', 'purchase', 'ajout au panier'
];

// Fonction stricte pour vérifier si un élément est un bouton d'achat
function isStrictlyBuyButton(element) {
  // Vérifier si c'est un élément cliquable
  const isClickable = element.tagName === 'BUTTON' || 
                      element.tagName === 'A' || 
                      element.tagName === 'INPUT' && (element.type === 'submit' || element.type === 'button');
  
  if (!isClickable) {
    // Vérifier s'il a un rôle de bouton
    const role = element.getAttribute('role');
    if (role !== 'button') {
      return false;
    }
  }
  
  // Vérification du texte - doit contenir l'un des mots clés EXACTS
  if (element.textContent) {
    const text = element.textContent.toLowerCase().trim();
    // Vérification stricte du texte
    if (buyKeywords.some(keyword => {
      // Vérification exacte du texte
      return text === keyword || 
             text.includes(keyword) && text.length < keyword.length + 10;
    })) {
      console.log("Bouton d'achat détecté par texte:", text);
      return true;
    }
  }
  
  // Vérification des attributs spécifiques aux boutons d'achat
  const attrs = ['id', 'class', 'name', 'aria-label', 'title', 'data-testid'];
  for (const attr of attrs) {
    const value = element.getAttribute(attr);
    if (value) {
      const valueLower = value.toLowerCase();
      // Vérification plus stricte des attributs
      if (
        valueLower.includes('add-to-cart') || 
        valueLower.includes('addtocart') || 
        valueLower.includes('add_to_cart') ||
        valueLower.includes('buy-now') ||
        valueLower.includes('checkout') ||
        valueLower.includes('ajout-panier') ||
        valueLower.includes('acheter-maintenant')
      ) {
        console.log("Bouton d'achat détecté par attribut:", attr, "=", value);
        return true;
      }
    }
  }
  
  return false;
}

// Écouteur d'événement global pour les clics
document.addEventListener('click', function(event) {
  // Ne rien faire si une popup est déjà visible
  if (popupIsVisible) {
    return;
  }
  
  // Vérifier l'élément cliqué et ses parents proches
  let currentElement = event.target;
  let depth = 0;
  let isButtonFound = false;
  
  // Vérifier l'élément et ses parents jusqu'à 3 niveaux
  while (currentElement && depth < 4) {
    if (isStrictlyBuyButton(currentElement)) {
      isButtonFound = true;
      break;
    }
    currentElement = currentElement.parentElement;
    depth++;
  }
  
  if (isButtonFound) {
    console.log("Bouton d'achat détecté - Affichage de la popup");
    // Empêcher l'action par défaut du clic
    event.preventDefault();
    event.stopPropagation();
    
    // Afficher la popup
    showPopup();
    
    // Éviter la propagation du clic
    return false;
  }
}, true); // Utiliser la phase de capture pour intercepter les clics

function showPopup() {
  // Marquer qu'une popup est visible
  popupIsVisible = true;
  
  // Créer l'overlay
  const overlay = document.createElement('div');
  overlay.className = 'reflection-overlay';
  
  // Créer la popup
  const popup = document.createElement('div');
  popup.className = 'reflection-popup';
  
  // Contenu de la popup
  popup.innerHTML = `
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <h2>Why should you consume?</h2>
    <img src="${chrome.runtime.getURL('imgs/shock-image.jpg')}" alt="Image de sensibilisation">
    <figcation>Imported secondhand clothes pile up in Accra, Ghana, earlier this year. Photograph: Muntaka Chasant/Rex/Shutterstock</figcaption>
    <p>Take a moment to think about the impact of your consumption on the world. Do you really need it ?</p>
    <div class="button-container">
      <button class="close-button">close</button>
    </div>
  `;
  
  // Ajouter la popup à l'overlay
  overlay.appendChild(popup);
  document.body.appendChild(overlay);
  
  // Ajouter l'écouteur d'événement au bouton de fermeture
  const closeButton = popup.querySelector('.close-button');
  closeButton.addEventListener('click', function() {
    closePopup();
  });
  
  // Permettre de fermer en cliquant sur l'overlay
  overlay.addEventListener('click', function(event) {
    if (event.target === overlay) {
      closePopup();
    }
  });
  
  // Permettre de fermer avec la touche Echap
  document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
      closePopup();
    }
  });
}

function closePopup() {
  const overlay = document.querySelector('.reflection-overlay');
  if (overlay) {
    document.body.removeChild(overlay);
  }
  popupIsVisible = false;
}

// Ajouter un message de débogage pour confirmer que l'extension est chargée
console.log("Extension 'Réflexion Avant Achat' activée - Version stricte");
